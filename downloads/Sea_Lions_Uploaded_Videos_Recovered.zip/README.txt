SEA LIONS: RECOVERED COPIES OF INSTRUCTOR-UPLOADED VIDEOS

Only recordings explicitly documented as instructor-provided/uploaded are included. Videos sourced elsewhere are excluded.

IMPORTANT: These are the copies retained in the repository and used in the lectures. Some are excerpts or compatible/compressed copies, not the complete original uploads. Complete originals for the excerpt-only sources are not tracked in the repository. Filenames have not been relabeled as originals. CONTENTS.json identifies every retained copy and its uploaded source.

Sea Lions I: lecture91 branch, Lecture 91. Sea Lions II: authoritative default branch, Lecture 94. No lecture decks were changed.
